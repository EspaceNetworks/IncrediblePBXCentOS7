#!/usr/bin/php -q
<?php 
 ob_implicit_flush(false); 
 error_reporting(0); 
 set_time_limit(300);    

$fd = fopen("/tmp/theanswer.txt", "r");
$theanswer = "";
while(!feof($fd)){
        $theanswer .= fread($fd, 4096);   
} 
fclose($fd);

function GetResults($response)
{
    global $results;
    $response = str_replace("|",",",$response);
    $response = str_replace("°F","degrees fahrenheit",$response);
    $response = str_replace(" mph"," miles per hour",$response);
    $response = str_replace("USA","United States",$response);
    $response = str_replace("US","United States",$response);
    $response = str_replace("wind","wend",$response);
    $response = str_replace("&apos;","'",$response);
    $response = str_replace("Jr.","junior",$response);
    $response = str_replace("Sr.","senior",$response);
    $response = str_replace("Dr.","doctor",$response);
    $response = str_replace("Rev.","reverend",$response);
    $response = str_replace(" mg "," milligrams ",$response);
    $response = str_replace(" g "," grams ",$response);
    $response = str_replace(" am "," a.m. ",$response);
    $response = str_replace(" pm "," p.m. ",$response);
    $startPos = strpos($response, "<plaintext>") + 11;
    $endPos = strpos($response, "</plaintext>");
    $length =  $endPos - $startPos;
 
    if ($length > 2) :
        $response = str_replace(chr(10),",",$response);
        return substr($response, $startPos, $length);   
    else :
        $results=$results.chr(13).chr(10);
        echo $results ;
        echo chr(13).chr(10) ;
        echo chr(13).chr(10) ;
        $fd = fopen("/tmp/results.txt", "w");
        fwrite($fd, $results);
        fclose($fd);
        exit;
    endif ;
}

$results = "";
while (strlen($theanswer)>20) {
  $results = $results . GetResults($theanswer) . "." . chr(13) . chr(10) ;
  $endPos = strpos($theanswer, "</plaintext>")+12;
  $theanswer=substr($theanswer,$endPos);  
}

?>
