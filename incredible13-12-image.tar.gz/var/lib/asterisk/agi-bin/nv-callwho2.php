#!/usr/bin/php -q 
<?php
 ob_implicit_flush(false); 
 error_reporting(0); 
 set_time_limit(300); 
 $ttsengine[0] = "flite" ;
 $ttsengine[1] = "swift" ;

//-------- DON'T CHANGE ANYTHING ABOVE THIS LINE ----------------

 $debug = 1; 
 $newlogeachdebug = 1;
 $emaildebuglog = 0;
 $email = "yourname@yourdomain" ;
 $ttspick = 0 ;

//-------- DON'T CHANGE ANYTHING BELOW THIS LINE ----------------

//   Nerd Vittles' CallWho for Asteridex ver. 1.0, (c) Copyright Ward Mundy, 2008. All rights reserved.
//   Nerd Vittles' CallWho for Asteridex comes with ABSOLUTELY NO WARRANTY EXPRESSED OR IMPLIED. USE IT SOLELY ARE YOUR RISK!
//   This is free software, with components licensed under the GNU General Public
//   License version 2 and other licenses. You are welcome to redistribute it subject to the terms
//   of the license agreement. Do NOT sell something for which you paid nothing. Enjoy!

//   Before using this application, you must first run the dialcode.php application using a web browser to populate AsteriDex dialcodes.
//   For complete documentation, visit http://nerdvittles.com


$log = "/var/log/asterisk/nv-callwho.txt" ;
if ($debug and $newlogeachdebug) :
 if (file_exists($log)) :
  unlink($log) ;
 endif ;
endif ;

 $stdlog = fopen($log, 'a'); 
 $stdin = fopen('php://stdin', 'r'); 
 $stdout = fopen( 'php://stdout', 'w' ); 

if ($debug) :
  fputs($stdlog, "Nerd Vittles CallWho for Asteridex ver. 1.0 (c) Copyright 2008, Ward Mundy. All Rights Reserved.\n\n" . date("F j, Y - H:i:s") . "  *** New session ***\n\n" ); 
endif ;

function read() {  
 global $stdin;  
 $input = str_replace("\n", "", fgets($stdin, 4096));  
 dlog("read: $input\n");  
 return $input;  
}  

function write($line) {  
 dlog("write: $line\n");  
 echo $line."\n";  
}  

function dlog($line) { 
 global $debug, $stdlog; 
 if ($debug) fputs($stdlog, $line); 
} 

function execute_agi( $command ) 
{ 
GLOBAL $stdin, $stdout, $stdlog, $debug; 
 
fputs( $stdout, $command . "\n" ); 
fflush( $stdout ); 
if ($debug) 
fputs( $stdlog, $command . "\n" ); 
 
$resp = fgets( $stdin, 4096 ); 
 
if ($debug) 
fputs( $stdlog, $resp ); 
 
if ( preg_match("/^([0-9]{1,3}) (.*)/", $resp, $matches) )  
{ 
if (preg_match('/result=([-0-9a-zA-Z]*)(.*)/', $matches[2], $match))  
{ 
$arr['code'] = $matches[1]; 
$arr['result'] = $match[1]; 
if (isset($match[3]) && $match[3]) 
$arr['data'] = $match[3]; 
return $arr; 
}  
else  
{ 
if ($debug) 
fputs( $stdlog, "Couldn't figure out returned string, Returning code=$matches[1] result=0\n" );  
$arr['code'] = $matches[1]; 
$arr['result'] = 0; 
return $arr; 
} 
}  
else  
{ 
if ($debug) 
fputs( $stdlog, "Could not process string, Returning -1\n" ); 
$arr['code'] = -1; 
$arr['result'] = -1; 
return $arr; 
} 
}  


// ------ Code execution begins here

while ( !feof($stdin) )  
{ 
$temp = fgets( $stdin ); 
 
if ($debug) 
fputs( $stdlog, $temp ); 
 
// Strip off any new-line characters 
$temp = str_replace( "\n", "", $temp ); 
 
$s = explode( ":", $temp ); 
$agivar[$s[0]] = trim( $s[1] ); 
if ( ( $temp == "") || ($temp == "\n") ) 
{ 
break; 
} 
}  

$dialcode = $_SERVER["argv"][1];
if ($debug) :
fputs($stdlog, "DIALCODE: " . $dialcode . "\n" );
endif ;

$tts = $ttsengine[$ttspick] ;


if ($dialcode<"222") :
 if ($debug) :
  fputs($stdlog, "DIALCODE is not of acceptable length.\n" );
 endif ;
 $msg=chr(34)."The dial code you entered in not in the correct format. Goodbye." . chr(34) ;
 execute_agi("exec $tts $msg") ;
 $num2call = "0" ;
 execute_agi("SET VARIABLE NUM2CALL $num2call");

if ($emaildebuglog) :
 system("mime-construct --to $email --subject " . chr(34) . "Nerd Vittles CallWho for Asteridex ver. 1.0 Session Log" . chr(34) . " --attachment $log --type text/plain --file $log") ;
endif ;

 exit ;
endif ;


$token = md5 (uniqid (""));
$tmptext = "/tmp/tts-$token.txt" ;
$tmpwave = "/var/lib/asterisk/sounds/tts/tts-$token.wav" ;
$newsfull="";
$news="";

//mysql database connection settings
$dbhost = "localhost";
$dbpass = "passw0rd";
$dbuser = "root";
$dbname = "asteridex";

$dbconnection = mysql_connect($dbhost, $dbuser, $dbpass) or die("Database connection failed");

mysql_select_db($dbname) or die("data base open failed");
$query = "SELECT * FROM user1 where dialcode = '$dialcode' order by name asc";
$result = mysql_query($query) or die("Web site query failed");
if (mysql_numrows($result)<1):
 $msg=chr(34)."No matching dialcode was found. Goodbye" . chr(34) ;
 execute_agi("exec $tts $msg") ;
 mysql_close($dbconnection);
 $num2call = "0" ;
 execute_agi("SET VARIABLE NUM2CALL $num2call");

if ($emaildebuglog) :
 system("mime-construct --to $email --subject " . chr(34) . "Nerd Vittles CallWho for Asteridex ver. 1.0 Session Log" . chr(34) . " --attachment $log --type text/plain --file $log") ;
endif ;

 exit ;
elseif (mysql_numrows($result)<2):
 $row = mysql_fetch_array($result);
 $num2call = "$row[3]";
 $person2call = "$row[1]";
 $msg=chr(34)."Calling $person2call. One moment please." . chr(34) ;
 execute_agi("exec $tts $msg") ;
 mysql_close($dbconnection);
 execute_agi("SET VARIABLE NUM2CALL $num2call");

if ($emaildebuglog) :
 system("mime-construct --to $email --subject " . chr(34) . "Nerd Vittles CallWho for Asteridex ver. 1.0 Session Log" . chr(34) . " --attachment $log --type text/plain --file $log") ;
endif ;

 exit ;
endif ;
$counter=1 ;
$mynum2call[0]="0";
$myperson2call[0] = "nobody";
$choices=mysql_numrows($result);
if ($choices>9) :
 $choices=9;
endif;
$msg = $msg . chr(34) . "After the beep, ";
while ($row = mysql_fetch_array($result) and $counter<=$choices) {
 $mynum2call[$counter]="$row[3]";
 $myperson2call[$counter] = "$row[1]";
 $msg = $msg . "press ".$counter." for $myperson2call[$counter]: ";
 $counter=$counter+1;
}
mysql_close($dbconnection);
$msg = $msg . chr(34) ;
$num2call = "0" ;
execute_agi("exec $tts $msg") ;
$rc1 = execute_agi( "GET DATA beep 5000 1");
if ($rc1[result]==-1) :
  $num2call = "0" ;
elseif ($rc1[result]==0) :
  $num2call = "0" ;
elseif ($rc1[result]>$choices) :
  $num2call = "0" ;
else  :
  $pick = $rc1[result] ;
  $num2call = $mynum2call[$pick];
  $person2call = $myperson2call[$pick];
endif ;
if ($num2call<>0) :
 $msg=chr(34)."Calling $person2call. One moment please." . chr(34) ;
else :
 $msg=chr(34)."No matching entry was found. Goodbye" . chr(34) ;
endif;
execute_agi("exec $tts $msg") ;
execute_agi("SET VARIABLE NUM2CALL $num2call");


if ($emaildebuglog) :
 system("mime-construct --to $email --subject " . chr(34) . "Nerd Vittles CallWho for Asteridex ver. 1.0 Session Log" . chr(34) . " --attachment $log --type text/plain --file $log") ;
endif ;


// clean up file handlers etc.  
fclose($stdin);  
fclose($stdout);
fclose($stdlog);  
exit;
?>
