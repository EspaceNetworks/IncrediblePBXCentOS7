#!/usr/bin/php -q
<?php
 ob_implicit_flush(false);
 error_reporting(0);
 set_time_limit(300);

//   Nerd Vittles Google News ver. 1.0, (c) Copyright Ward Mundy, 2007-2012. All rights reserved.

//                    This software is licensed under the GPL2 license.
//
//   Material alteration of the spoken content provided by this application is strictly prohibited.
//
//   For a copy of license, visit http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
//
//    For additional information, contact us: http://pbxinaflash.com/about/comment.php


//-------- DON'T CHANGE ANYTHING ABOVE THIS LINE ----------------


 $debug = 1;
 $newlogeachdebug = 1;
 $emaildebuglog = 0;
 $email = "yourname@yourdomain" ;


//-------- DON'T CHANGE ANYTHING BELOW THIS LINE ----------------


$log = "/var/log/asterisk/nv-news-google.txt" ;
if ($debug and $newlogeachdebug) :
 if (file_exists($log)) :
  unlink($log) ;
 endif ;
endif ;

 $stdlog = fopen($log, 'a'); 
 $stdin = fopen('php://stdin', 'r'); 
 $stdout = fopen( 'php://stdout', 'w' ); 

if ($debug) :
  fputs($stdlog, "Nerd Vittles Google News ver. 1.0 (c) Copyright 2007-2012, Ward Mundy. All Rights Reserved.\n\n" . date("F j, Y - H:i:s") . "  *** New session ***\n\n" ); 
endif ;

function read() {  
 global $stdin;  
 $input = str_replace("\n", "", fgets($stdin, 4096));  
 dlog("read: $input\n");  
 return $input;  
}  

function write($line) {  
 dlog("write: $line\n");  
 echo $line."\n";  
}  

function dlog($line) { 
 global $debug, $stdlog; 
 if ($debug) fputs($stdlog, $line); 
} 

function execute_agi( $command ) 
{ 
GLOBAL $stdin, $stdout, $stdlog, $debug; 
 
fputs( $stdout, $command . "\n" ); 
fflush( $stdout ); 
if ($debug) 
fputs( $stdlog, $command . "\n" ); 
 
$resp = fgets( $stdin, 4096 ); 
 
if ($debug) 
fputs( $stdlog, $resp ); 
 
if ( preg_match("/^([0-9]{1,3}) (.*)/", $resp, $matches) )  
{ 
if (preg_match('/result=([-0-9a-zA-Z]*)(.*)/', $matches[2], $match))  
{ 
$arr['code'] = $matches[1]; 
$arr['result'] = $match[1]; 
if (isset($match[3]) && $match[3]) 
$arr['data'] = $match[3]; 
return $arr; 
}  
else  
{ 
if ($debug) 
fputs( $stdlog, "Couldn't figure out returned string, Returning code=$matches[1] result=0\n" );  
$arr['code'] = $matches[1]; 
$arr['result'] = 0; 
return $arr; 
} 
}  
else  
{ 
if ($debug) 
fputs( $stdlog, "Could not process string, Returning -1\n" ); 
$arr['code'] = -1; 
$arr['result'] = -1; 
return $arr; 
} 
}  

// ------ Code execution begins here
// parse agi headers into array  
//while ($env=read()) {  
// $s = split(": ",$env);  
// $agi[str_replace("agi_","",$s0)] = trim($s1); 
// if (($env == "") || ($env == "\n")) {  
//   break;  
// }  
//}  

while ( !feof($stdin) )  
{ 
$temp = fgets( $stdin ); 
 
if ($debug) 
fputs( $stdlog, $temp ); 
 
// Strip off any new-line characters 
$temp = str_replace( "\n", "", $temp ); 
 
$s = explode( ":", $temp ); 
$agivar[$s[0]] = trim( $s[1] ); 
if ( ( $temp == "") || ($temp == "\n") ) 
{ 
break; 
} 
}  

$items = $_SERVER["argv"][1];
$items=trim($items);


if ($debug) :
fputs($stdlog, "News items requested: " . $items . "\n" );
endif ;


$query = "http://www.google.com/ig/api?news";


$fd = fopen($query, "r");
if (!$fd) {
 echo "<p>Unable to open web connection. \n";
 exit;
}
$value = "";
while(!feof($fd)){
        $value .= fread($fd, 4096);
}
fclose($fd);


  if ($debug) :
   fputs($stdlog, "News Data: " . $value . "\n\n" );
  endif ;

//echo $value;
//echo chr(10).chr(10);

$thetext="<title data=";
$endtext=chr(34)."/>";
$start= strpos($value, $thetext);
$value = substr($value,$start+strlen($thetext)+1);
$msg = "This Top Stories news update brought to you by Google and Nerd Viddles. ";

$i=1;
while ($i <= $items) :
$thetext="<title data=";
$endtext=chr(34)."/>";
$start= strpos($value, $thetext);
//echo $start . chr(10);
$tmptext = substr($value,$start+strlen($thetext)+1);
//echo $start+strlen($thetext)+1;
//echo chr(10);
$end=strpos($tmptext, $endtext);
//echo $end . chr(10);
$title = trim(substr($tmptext,0,$end));
$lent= strlen($title);
if ( substr($title,$lent)<>"." ):
 $title=$title.".";
endif;
$value = substr($value,$start+strlen($thetext)+1);
//echo $title;

$thetext="<source data=";
$endtext=chr(34)."/>";
$start= strpos($value, $thetext);
//echo $start . chr(10);
$tmptext = substr($value,$start+strlen($thetext)+1);
//echo $start+strlen($thetext)+1;
//echo chr(10);
$end=strpos($tmptext, $endtext);
//echo $end . chr(10);
$source = trim(substr($tmptext,0,$end));
$value = substr($value,$start+strlen($thetext)+1);

$msg = $msg . "From ". $source . ": " . $title . " ";
//echo $source.chr(10);

$i++;
endwhile;

$msg = str_replace( "&amp;amp;#39;", "'", $msg );
$msg = str_replace( "&amp;quot;", "", $msg );
$msg = str_replace( "&amp;amp;quot;", "", $msg );
$msg = str_replace( "&amp;#39;","'", $msg );
$msg = str_replace( ",", " ", $msg );
$msg= chr(34). $msg. "Have a nice day. Goodbye.".chr(34);

if ($debug) :
fputs($stdlog, "News Update: " . $msg . "\n" );
endif ;

execute_agi("SET VARIABLE NEWS $msg");

//echo $msg;
//echo chr(10);
//echo chr(10);

if ($emaildebuglog) :
 system("mime-construct --to $email --subject " . chr(34) . "Nerd Vittles Google News ver. 1.0 Session Log" . chr(34) . " --attachment $log --type text/plain --file $log") ;
endif ;

// clean up file handlers etc.
fclose($stdin);
fclose($stdout);
fclose($stdlog);
exit;

?>
