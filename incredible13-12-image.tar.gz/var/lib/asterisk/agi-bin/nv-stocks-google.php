#!/usr/bin/php -q
<?php
 ob_implicit_flush(false);
 error_reporting(0);
 set_time_limit(300);

//   Nerd Vittles Google Stocks ver. 1.0, (c) Copyright Ward Mundy, 2007-2012. All rights reserved.

//                    This software is licensed under the GPL2 license.
//
//   Material alteration of the spoken content provided by this application is strictly prohibited.
//
//   For a copy of license, visit http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
//
//    For additional information, contact us: http://pbxinaflash.com/about/comment.php


//-------- DON'T CHANGE ANYTHING ABOVE THIS LINE ----------------


 $debug = 1;
 $newlogeachdebug = 1;
 $emaildebuglog = 0;
 $email = "yourname@yourdomain" ;

 $stock[0] = "BAC"    ; // Bank of America
 $stock[1] = "GOOG"   ; // Google
 $stock[2] = "AXP"    ; // American Express
 $stock[3] = "DIS"    ; // Walt Disney
 $stock[4] = "IBM"    ; // IBM
 $stock[5] = "KO"     ; // Coca Cola
 $stock[6] = "MSFT"   ; // Microsoft
 $stock[7] = "PFE"    ; // Phizer
 $stock[8] = "T"      ; // AT&T
 $stock[9] = "WMT"    ; // Wal-Mart


//-------- DON'T CHANGE ANYTHING BELOW THIS LINE ----------------


$log = "/var/log/asterisk/nv-stocks-google.txt" ;
if ($debug and $newlogeachdebug) :
 if (file_exists($log)) :
  unlink($log) ;
 endif ;
endif ;

 $stdlog = fopen($log, 'a'); 
 $stdin = fopen('php://stdin', 'r'); 
 $stdout = fopen( 'php://stdout', 'w' ); 

if ($debug) :
  fputs($stdlog, "Nerd Vittles Google Stocks ver. 1.0 (c) Copyright 2007-2012, Ward Mundy. All Rights Reserved.\n\n" . date("F j, Y - H:i:s") . "  *** New session ***\n\n" ); 
endif ;

function read() {  
 global $stdin;  
 $input = str_replace("\n", "", fgets($stdin, 4096));  
 dlog("read: $input\n");  
 return $input;  
}  

function write($line) {  
 dlog("write: $line\n");  
 echo $line."\n";  
}  

function dlog($line) { 
 global $debug, $stdlog; 
 if ($debug) fputs($stdlog, $line); 
} 

function execute_agi( $command ) 
{ 
GLOBAL $stdin, $stdout, $stdlog, $debug; 
 
fputs( $stdout, $command . "\n" ); 
fflush( $stdout ); 
if ($debug) 
fputs( $stdlog, $command . "\n" ); 
 
$resp = fgets( $stdin, 4096 ); 
 
if ($debug) 
fputs( $stdlog, $resp ); 
 
if ( preg_match("/^([0-9]{1,3}) (.*)/", $resp, $matches) )  
{ 
if (preg_match('/result=([-0-9a-zA-Z]*)(.*)/', $matches[2], $match))  
{ 
$arr['code'] = $matches[1]; 
$arr['result'] = $match[1]; 
if (isset($match[3]) && $match[3]) 
$arr['data'] = $match[3]; 
return $arr; 
}  
else  
{ 
if ($debug) 
fputs( $stdlog, "Couldn't figure out returned string, Returning code=$matches[1] result=0\n" );  
$arr['code'] = $matches[1]; 
$arr['result'] = 0; 
return $arr; 
} 
}  
else  
{ 
if ($debug) 
fputs( $stdlog, "Could not process string, Returning -1\n" ); 
$arr['code'] = -1; 
$arr['result'] = -1; 
return $arr; 
} 
}  

// ------ Code execution begins here
// parse agi headers into array  
//while ($env=read()) {  
// $s = split(": ",$env);  
// $agi[str_replace("agi_","",$s0)] = trim($s1); 
// if (($env == "") || ($env == "\n")) {  
//   break;  
// }  
//}  

while ( !feof($stdin) )  
{ 
$temp = fgets( $stdin ); 
 
if ($debug) 
fputs( $stdlog, $temp ); 
 
// Strip off any new-line characters 
$temp = str_replace( "\n", "", $temp ); 
 
$s = explode( ":", $temp ); 
$agivar[$s[0]] = trim( $s[1] ); 
if ( ( $temp == "") || ($temp == "\n") ) 
{ 
break; 
} 
}  

$symbol = $_SERVER["argv"][1];
$symbol=trim($symbol);

$symbol = str_replace( "alpha", "A", $symbol);
$symbol = str_replace( "bravo", "B", $symbol);
$symbol = str_replace( "charlie", "C", $symbol);
$symbol = str_replace( "delta", "D", $symbol);
$symbol = str_replace( "echo", "E", $symbol);
$symbol = str_replace( "foxtrot", "F", $symbol);
$symbol = str_replace( "golf", "G", $symbol);
$symbol = str_replace( "hotel", "H", $symbol);
$symbol = str_replace( "india", "I", $symbol);
$symbol = str_replace( "juliet", "J", $symbol);
$symbol = str_replace( "kilo", "K", $symbol);
$symbol = str_replace( "lima", "L", $symbol);
$symbol = str_replace( "mike", "M", $symbol);
$symbol = str_replace( "november", "N", $symbol);
$symbol = str_replace( "oscar", "O", $symbol);
$symbol = str_replace( "papa", "P", $symbol);
$symbol = str_replace( "quebec", "Q", $symbol);
$symbol = str_replace( "romeo", "R", $symbol);
$symbol = str_replace( "sierra", "S", $symbol);
$symbol = str_replace( "tango", "T", $symbol);
$symbol = str_replace( "uniform", "U", $symbol);
$symbol = str_replace( "victor", "V", $symbol);
$symbol = str_replace( "whiskey", "W", $symbol);
$symbol = str_replace( "x ray", "X", $symbol);
$symbol = str_replace( "x-ray", "X", $symbol);
$symbol = str_replace( "yankee", "Y", $symbol);
$symbol = str_replace( "zulu", "Z", $symbol);

$symbol = str_replace( "letter eye", "i", $symbol);
$symbol = str_replace( "letter to", "q", $symbol);
$symbol = str_replace( "letter im", "m", $symbol);
$symbol = str_replace( "letter in", "n", $symbol);
$symbol = str_replace( "letter and", "n", $symbol);
$symbol = str_replace( "letter page", "h", $symbol);
$symbol = str_replace( "letter you", "u", $symbol);
$symbol = str_replace( "letter text", "x", $symbol);

$symbol = str_replace( "zero", "0", $symbol);
$symbol = str_replace( "one", "1", $symbol);
$symbol = str_replace( "won", "1", $symbol);
$symbol = str_replace( "two", "2", $symbol);
$symbol = str_replace( "too", "2", $symbol);
$symbol = str_replace( "to", "2", $symbol);
$symbol = str_replace( "tube", "2", $symbol);
$symbol = str_replace( "three", "3", $symbol);
$symbol = str_replace( "four", "4", $symbol);
$symbol = str_replace( "fore", "4", $symbol);
$symbol = str_replace( "five", "5", $symbol);
$symbol = str_replace( "six", "6", $symbol);
$symbol = str_replace( "seven", "7", $symbol);
$symbol = str_replace( "eight", "8", $symbol);
$symbol = str_replace( "ate", "8", $symbol);
$symbol = str_replace( "nine", "9", $symbol);

$symbol = str_replace( "letters", "", $symbol);
$symbol = str_replace( "letter", "", $symbol);
$symbol = str_replace( "numbers", "", $symbol);
$symbol = str_replace( "number", "", $symbol);
$symbol = str_replace( "phonetic", "", $symbol);
$symbol = str_replace( "fanatics", "", $symbol);

$pos=0;
$newsymbol=$symbol." ";
$m=strpos($newsymbol," ");
while ($m<>0){
 $testword = substr($newsymbol,0,$m);
 echo $testword;
 echo chr(10);
 if (strlen($testword)>1):
  $symbol = str_replace( $testword, substr($testword,0,1), $symbol);
 endif;
 $newsymbol=substr($newsymbol,$m+1);
 $m=strpos($newsymbol," ");
}

$symbol = str_replace( " ", "", $symbol);


if ( $symbol=="0" or $symbol=="1" or $symbol=="2" or $symbol=="3" or $symbol=="4" or $symbol=="5" or $symbol=="6" or $symbol=="7" or $symbol=="8" or $symbol=="9"  ):
 $symbol2=$stock[$symbol];
 $symbol=$symbol2;
endif;

$symbol = str_replace( " ", "", $symbol);

if ($debug) :
fputs($stdlog, "Stock symbol: " . $symbol . "\n" );
endif ;


$query = "http://www.google.com/ig/api?stock=$symbol";


$fd = fopen($query, "r");
if (!$fd) {
 echo "<p>Unable to open web connection. \n";
 exit;
}
$value = "";
while(!feof($fd)){
        $value .= fread($fd, 4096);
}
fclose($fd);

$found=strpos($value,"UNKNOWN EXCHANGE");
if ($found>0) :
  $msg=chr(34)."Sorry but no stock data is available for $symbol. Thank you for calling. Goodbye.".chr(34);
//  echo $msg;
//  echo chr(10);
  execute_agi("SET VARIABLE STOCK $msg");

  if ($debug) :
   fputs($stdlog, "Data: " . $msg . "\n" );
  endif ;

  exit;
endif;


  if ($debug) :
   fputs($stdlog, "Data: " . $value . "\n\n" );
  endif ;

//echo $value;
//echo chr(10).chr(10);

$thetext="<company data=";
$endtext=chr(34)."/>";
$start= strpos($value, $thetext);
//echo $start . chr(10);
$tmptext = substr($value,$start+strlen($thetext)+1);
//echo $start+strlen($thetext)+1;
//echo chr(10);
$end=strpos($tmptext, $endtext);
//echo $end . chr(10);
$company = substr($tmptext,0,$end);
//echo $company;

$company1=$company;
$company = "This stock report for $company brought to you by Google and Nerd Viddles. Do not rely upon this information to make financial decisions as the data may not be current.  ";
//echo $price.chr(10);


$thetext="<last data=";
$endtext=chr(34)."/>";
$start= strpos($value, $thetext);
//echo $start . chr(10);
$tmptext = substr($value,$start+strlen($thetext)+1);
//echo $start+strlen($thetext)+1;
//echo chr(10);
$end=strpos($tmptext, $endtext);
//echo $end . chr(10);
$price = substr($tmptext,0,$end);
//echo $location;
$price = str_replace( ".", " dollars and ", $price). " cents";


$price = "Trade results delayed at least 15 minutes on many stock exchanges. Google's Last reported trade price for $company1 $price. ";
//echo $price.chr(10);


$msg= chr(34).$company.$price."Have a nice day. Goodbye.".chr(34);
$msg = str_replace( ",", " ", $msg );

if ($debug) :
fputs($stdlog, "Stock Update: " . $msg . "\n" );
endif ;

execute_agi("SET VARIABLE STOCK $msg");

//echo $msg;
//echo chr(10);
//echo chr(10);

if ($emaildebuglog) :
 system("mime-construct --to $email --subject " . chr(34) . "Nerd Vittles Google Stocks ver. 1.0 Session Log" . chr(34) . " --attachment $log --type text/plain --file $log") ;
endif ;

// clean up file handlers etc.
fclose($stdin);
fclose($stdout);
fclose($stdlog);
exit;

?>
