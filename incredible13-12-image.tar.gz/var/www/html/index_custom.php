<?php
/*
  =========================================================
   Contributed by Kennon Software's - Open Source Projects
   to the PBX-in-a-Flash Community

   Supports: AAH v1.x - V2.x / TrixBox v1.x / PBIAF v1.x

   v3.5 / Mar 2011
   - Converted to jQuery, HTML5, CSS3 with deprecated supp.
   
   v3.0 / Jun 2008
   - Updated specifically for PBIAF
   - Updated user-interface ("metal" style)
   - Optional RSS support
   - Web 2.0 enabled & initial effects applied
   - XHTML Strict compliant 
     (other than a couple non-W3C CSS hacks for IE6/7!)
   - Skinnable interface
   - Customizable buttons (easy to add your own if need be)
   - Optional UI Wrapper for calling apps (easier nav back)
   - Optional Reseller/End-user branding in "_branding.htm"
   - End-user & Admin menus can have different branding
   - Internationalization by editing the button definition
     file "/welcome/.htindex.cfg"
   - Better secured data files & password at the server

   More info can be found at: http://www.kennonsoft.org/ 
  =========================================================
*/


// Default values
error_reporting(E_ALL ^ E_NOTICE);
$host = $_SERVER['HTTP_HOST'];
if (strpos($host,":")>0) :
	$host = substr($host,0,strpos($host,":")) ;
endif ;
$pg = $_REQUEST["pg"]; // Optional tab redirect for admin logins, to enforce browser refresh goes to most relevent tab for Admin users

// Configure display experience
$uimode = "admin";
$admin = true;
$wrapper = false;
if (file_exists("welcome/.htindex.dat")) {
	// Read configuration
	$fp = fopen("welcome/.htindex.dat", "r");
	if ($fp) {
		$uiconfig = explode(",",fread($fp, filesize("welcome/.htindex.dat")));
// echo $uiconfig[0];
		fclose($fp);
		if (strtolower($uiconfig[0]) == "users") {
			$uimode = "users";
		}
		if (strtolower($uiconfig[3]) == "true") {
			$wrapper = true;
		}
	}
}

// Handle form post from password form (if applicable)
$post_error = "";
//echo $uiconfig[1];
if (array_key_exists("_submit", $_POST)) {
	if ($_POST["pwd"] == $uiconfig[1]) {
		setcookie("ksc-menu","0x123");
		header("Location: index.php?pg=2");
		exit;
	} else {
		setcookie("ksc-menu","");
		$post_error = "<span style=\"color:#ff0000\">Incorrect password!</span>";
	}
}

// If in "users" mode & Admin request, verify optional password
if (($uimode == "users") && ($uiconfig[1] != "")) {
	$admin = false;

	// Verify password in cookie
	if ($_COOKIE["ksc-menu"] == "0x123") {
		$admin = true;
	}
}

// Load array of components
if (file_exists("welcome/.htindex.cfg")) {
	// Read configuration
	$fp = fopen("welcome/.htindex.cfg", "r");
	if ($fp) {
		while (!feof($fp)) {
			$buffer = fgets($fp);
			$buffer = str_replace("\n", "", $buffer);
			$arrBuffer = explode(",",$buffer);
			$arrBuffer[2] = str_replace("$"."host", $host, $arrBuffer[2]); 			// $host variable substitutions for local URL entries
			$arr[$arrBuffer[1]] = $arrBuffer[2];							// File/URL path
			$arrUI[$arrBuffer[1]] = array($arrBuffer[0],$arrBuffer[3],$arrBuffer[4],true);	// UI row priority, Label, Icon, User-menu display (T/F)
		}
		fclose($fp);
	}
}

// Distro Versions Simple Check
if (file_exists("admin/images/custom-logo.png")) {
	$ver = "4"; // PBIAF v1.x
} else if (file_exists("maint/endpointcfg/cisco/phoneaddmac.php")) {
	$ver = "3"; // TrixBox v1.x
	$arr["admin"] = "./maint";
} else if (!file_exists($arr["a2billing"])) {
	$ver = "1"; // AAH v1.x
	$arr["admin"] = "./admin";
	$arrUI["admin"][1] = "Incredible PBX Administration";
} else {
	$ver = "2"; // AAH v2.x
}

// echo $ver;

// Confirm existence of each application, clear value if not available, tally for menu priority over-loads reordering (i.e. $intA[])
$intA = array(0,0,0,0,0);

foreach ($arr as $key => $value) {

   // If in "users" mode, disable unwanted end-user menu options
   $chosen = false;
   if ($uimode == "users") {
      foreach ($uiconfig as $key2 => $value2) {
         if (($key2 > 2) && ($value2 == $key)) {
            $chosen = true;
//          echo $key2.":".$value2."  ";
         }
      }
      if (!$chosen) { $arrUI[$key][3] = false; }
   } else {
      $chosen = true;
   }

   if (strtolower(substr($value,0,4)) == "http") {
		$tmp = $value;
		if (strtolower(substr($value,0,5)) == "https") {
			$tmp = "ssl".substr($value,5,strlen($value)-5);
		}
		if (!url_validate($tmp)) {
	      		$arr[$key] = "";
		} else {
			$intA[$arrUI[$key][0]] += 1;
		}

   } else {
	   if (!file_exists($value)) {
		if (($key == "recordings") && ($ver == "1") && ($chosen)) {
			$arr[$key] = "/cgi-bin/vmail.cgi";
			$intA[$arrUI[$key][0]] += 1;
		} else {
		   	$arr[$key] = "";
		}
	   } else {
		$intA[$arrUI[$key][0]] += 1;
	   }
   }
}

// Menu Tier Overloads, Reordering to maximize 15 main menu item limit (special admin-only 4th row of five items omitted purposefully)
// echo $intA[1]."=".$intA[2]."=".$intA[3]."=".$intA[4]; // Debug, show me available tier totals to ensure logic is correct!

// If 1st tier exceeds total - Demote
if ($intA[1] > 5) {
	foreach ($arr as $key => $value) {
		if ($arrUI[$key][0] == 1) {
			$counter += 1;
			if ($counter > 5) { 
				$arrUI[$key][0] = 2;	// Demote excess 1st tier menu item
				$intA[1] -= 1;	// Decrement prev tier total
				$intA[2] += 1;	// Increment next tier total
				$counter -= 1;
			}
		}
	}
}

// If 1st tier permits, and 2nd tier + 3rd tier exceeds total - Promote
if (($intA[1] < 5) && ($intA[2] + $intA[3] > 10)) {
	foreach ($arr as $key => $value) {
		if ($arrUI[$key][0] == 2) {
			if ($intA[2] + $intA[3] > 10) {
				if ($intA[1] < 5) {		// Promote
					$arrUI[$key][0] = 1;
					$intA[1] += 1;	// Increment prev tier total
					$intA[2] -= 1;	// Decrement next tier total
					$counter -= 1;
				}
			}
		}
	}
}

// If 2nd tier exceeds total - Demote
if ($intA[2] > 5) {
	foreach ($arr as $key => $value) {
		if ($arrUI[$key][0] == 2) {
			$counter += 1;
			if ($counter > 5) { 
				$arrUI[$key][0] = 3;	// Demote excess 1st tier menu item
				$intA[2] -= 1;	// Decrement prev tier total
				$intA[3] += 1;	// Increment next tier total
				$counter -= 1;
			}
		}
	}
}

// If 2nd tier permits, and 3rd tier exceeds total - Promote
if (($intA[2] < 5) && ($intA[3] > 5)) {
	foreach ($arr as $key => $value) {
		if ($arrUI[$key][0] == 3) {
			if ($intA[3] > 5) {
				if ($intA[2] < 5) {		// Promote
					$arrUI[$key][0] = 2;
					$intA[2] += 1;	// Increment prev tier total
					$intA[3] -= 1;	// Decrement next tier total
					$counter -= 1;
				}
			}
		}
	}
}

// If 3rd tier exceeds total - Only render first five in UI!

// Render UI HTML
$htmlAdmin = "";
if ($intA[3] == 0) {
	// Spacer
	$htmlAdmin .= '					<div class="spacer"><img src="welcome/pt.gif" /></div>'."\n";

	// Render 1st - 2nd Tiers
	$htmlAdmin .= renderMenuItems($intA,$arr,$arrUI,1,false,$wrapper);
	$htmlAdmin .= renderMenuItems($intA,$arr,$arrUI,2,false,$wrapper);
	$htmlAdmin .= '					<span class="hr"><img src="welcome/pt.gif" /></span>'."\n";
	$htmlAdmin .= renderMenuItems($intA,$arr,$arrUI,4,false,$wrapper);
	$htmlAdmin .= '					<span class="hr"><img src="welcome/pt.gif" /></span>'."\n";
} else {
	// Render 1st - 3rd Tiers
	$htmlAdmin .= renderMenuItems($intA,$arr,$arrUI,1,false,$wrapper);
	$htmlAdmin .= renderMenuItems($intA,$arr,$arrUI,2,false,$wrapper);
	$htmlAdmin .= renderMenuItems($intA,$arr,$arrUI,3,false,$wrapper);
	$htmlAdmin .= '					<span class="hr"><img src="welcome/pt.gif" /></span>'."\n";
	$htmlAdmin .= renderMenuItems($intA,$arr,$arrUI,4,false,$wrapper);
	$htmlAdmin .= '					<span class="hr"><img src="welcome/pt.gif" /></span>'."\n";
}

$htmlUsers = "";
if ($intA[3] == 0) {
	// Spacer
	$htmlUsers .= '					<div class="spacer"><img src="welcome/pt.gif" /></div>'."\n";

	// Render 1st - 2nd Tiers
	$htmlUsers .= renderMenuItems($intA,$arr,$arrUI,1,true,$wrapper);
	$htmlUsers .= renderMenuItems($intA,$arr,$arrUI,2,true,$wrapper);
} else {
	// Render 1st - 3rd Tiers
	$htmlUsers .= renderMenuItems($intA,$arr,$arrUI,1,true,$wrapper);
	$htmlUsers .= renderMenuItems($intA,$arr,$arrUI,2,true,$wrapper);
	$htmlUsers .= renderMenuItems($intA,$arr,$arrUI,3,true,$wrapper);
}

// RSS Feed Fetch & Format
$htmlRSS = "";
$rss =  simplexml_load_file($uiconfig[2]);
//echo $uiconfig[2];
foreach ($rss->channel->item as $item) {
	$htmlRSS .= '					<a href="'.$item->link.'" target="_rss">'.$item->title."</a><br/>"."\n";
	$htmlRSS .= $item->description."<br/><br/>"."\n";
//echo $htmlRSS;
}




// ===================
// Utility function(s)
// ===================

function url_validate( $link ) {        
	$url_parts = @parse_url( $link );

	if ( empty( $url_parts["host"] ) ) return( false );

	if ( !empty( $url_parts["path"] ) ) {
		$documentpath = $url_parts["path"];
	} else {
		$documentpath = "/";
	}

	if ( !empty( $url_parts["query"] ) ) {
		$documentpath .= "?" . $url_parts["query"];
	}

	$host = $url_parts["host"];
	if (substr($link,0,3) == "ssl") {
		$host = "ssl://".$host;
	}
	$port = $url_parts["port"];

	// Now (HTTP-)GET $documentpath at $host";

	if (empty( $port ) ) $port = "80";
	$socket = @fsockopen( $host, $port, $errno, $errstr, 30 );
	if (!$socket) {
		return(false);
	} else {
		fwrite ($socket, "HEAD ".$documentpath." HTTP/1.0\r\nHost: $host\r\n\r\n");
		$http_response = fgets( $socket, 22 );
           
		if ( strstr($http_response, "200 OK" ) || strstr($http_response, "200 Document" ) ) {
			fclose( $socket );
			return(true);
		} elseif ( strstr($http_response, "Not Impl" )) { 
			fclose( $socket );
			return(true); 
		} else {
//			echo "HTTP-Response: $http_response<br>";
			fclose( $socket );
			return(false);
		}
	}
}

function renderMenuItems( $intA, $arr, $arrUI, $tier, $enduser, $wrapper ) {
	$ret = "";
	if ($intA[$tier] > 0) {
		$counter = 0;
		foreach ($arr as $key => $value) {
			if (($arrUI[$key][0] == $tier) && ($arr[$key] != "")) {
				if ((!$enduser) || ($enduser && $arrUI[$key][3])) {
					$counter += 1;
					if ($counter <= 5) {
						if ($counter == 1) { $ret .= '					<div><table align="center" style="margin:0 auto 0 auto;"><tr><td>'."\n"; }
						$ret .= '						<a href="'.(($wrapper && $key != "menu") ? 'menu.php?id='.$key : $arr[$key]).'"><img src="welcome/'.$arrUI[$key][2].'"/>'.$arrUI[$key][1].'</a>'."\n";
					}
				}
			}
		}
		if ($counter > 0) { $ret .= "					</td></tr></table></div>"."\n"; }
	} else {
		// Spacer
		$ret .= '					<div class="spacer"><img src="welcome/pt.gif" /></div>'."\n";
	}

	return $ret;
}
?>
<!doctype html>

<!--[if lt IE 7 ]> <html lang="en" class="no-js ie6"> <![endif]-->
<!--[if IE 7 ]>    <html lang="en" class="no-js ie7"> <![endif]-->
<!--[if IE 8 ]>    <html lang="en" class="no-js ie8"> <![endif]-->
<!--[if IE 9 ]>    <html lang="en" class="no-js ie9"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--> <html lang="en" class="no-js"> <!--<![endif]-->
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

  <title>:: Incredible PBX, Welcome!</title>

  <meta name="description" content="Incredible PBX, Front End Menu">
  <meta name="author" content="Kennon Software Corporation">

  <link rel="stylesheet" href="welcome/css/style.css?v=1">
  <script src="welcome/js/libs/modernizr-1.7.min.js"></script>

</head>
<body>

	<div id="wrapper">
		<div id="left">
		
			<!-- LEFT COLUMN CONTENT -->
			<div id="logo"><a href="http://www.incrediblepbx.com/" target="_new" title="Visit the Incredible PBX website!"><img src="welcome/pt.gif" width="150" height="120" border="0"/></a></div>
<?php
   if ($htmlRSS != "") {
?>
			<div id="rss">
				<div id="scroller">
<?php echo $htmlRSS; ?>
				</div>
			</div>
<?php
   }

   if ($uimode == "users") { ?>
			<div id="wrap_menuswitch"><input type="checkbox" id="menuswitch" name="menutype" /></div>
<?php } ?>
		</div>

		<div id="right">

			<!-- RIGHT COLUMN CONTENT -->

<?php if ($uimode == "users") { ?>
			<!-- END-USER MENU -->
			<div id="users">

				<div id="buttons">
<?php echo $htmlUsers; ?>
					<img class="block_hr" src="welcome/pt.gif"/>
					<div class="spacer"><img src="welcome/pt.gif"/></div>
					<span class="hr"><img src="welcome/pt.gif" /></span>
				</div>

			</div>
<?php } ?>
<?php if ($admin == "true") { ?>
			<!-- ADMINISTRATIVE MENU -->
			<div id="admin">

				<div id="buttons">
<?php echo $htmlAdmin; ?>
				</div>

			</div>
<?php } else { ?>
			<!-- ADMINISTRATIVE LOGIN -->
			<div id="admin">
				<div id="buttons">
					<div id="login">
						<?php echo $post_error.'<br/><img class="block" src="welcome/pt.gif" height="5" />'."\n" ?>
						<form action="index.php" method="post">
							<input type="hidden" name="_submit" value="1" />
							Password:&nbsp;<input type="password" name="pwd" value="" style="width:100px" /><br />
							<img class="block" src="welcome/pt.gif" height="5" />
							<input type="submit" value="   Login   " />
						</form>
					</div>
				</div>
			</div>
<?php } ?>
			<div id="branding">

<?php include("_branding.htm"); ?>

			</div>
		</div>
	</div>
	
	<!-- CDN Scripts -->
	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js"></script>
	<script>!window.jQuery && document.write(unescape('%3Cscript src="welcome/js/libs/jquery-1.6.1.min.js"%3E%3C/script%3E'))</script>

	<!-- Scripts -->
	<script src="welcome/js/libs/jquery.easing.1.3.js"></script>
	<script src="welcome/js/libs/jquery.ibutton.min.js"></script>
	
	<!-- Scripts, Page Load -->
	<script type="text/javascript">
		$(document).ready(function() {
<?php if ($uimode == "users") { ?>
<?php
// Login error, or Successful Admin login tab switch convenience accomodation
if (($post_error != "") || ($pg == "2")) { 
	echo "			$('#menuswitch').attr('checked','checked');"."\n\n";
}
?>
			$('#menuswitch').iButton ({
				labelOn: "ADMIN",
				labelOff: "USERS",
				change: function ($input) {
					if ($input.is(":checked")) {
						menuShow(1);
					} else {
						menuShow(0);
					}
				}
			}).trigger("change");
		});

		function menuShow(el) {
			// Branding show
			if (el == 0) {
				$('#brand_admin').css('display','none');
				$('#brand_users').css('display','block');
			} else {
				$('#brand_users').css('display','none');
				$('#brand_admin').css('display','block');
			}

			// IE6/7/8 do not elegantly support fade effects with PNG images
			if ($.browser.msie && (parseInt($.browser.version, 10) < 9)) {
				if (el == 0) {
					$('#admin').css('display','none');
					$('#users').css('display','block');
				} else {
					$('#users').css('display','none');
					$('#admin').css('display','block');
				}
			} else {
				if (el == 0) {
					$('#admin').fadeOut("fast");//hide
					$('#users').fadeIn("fast"); //in
				} else {
					$('#users').fadeOut("fast"); //hide
					$('#admin').fadeIn("fast"); //in
				}
			}
		}
<?php } else { ?>
			// Branding show
			$('#brand_users').css('display','none');
			$('#brand_admin').css('display','block');

			// IE6/7 do not elegantly support fade effects with PNG images
			if ($.browser.msie && (parseInt($.browser.version, 10) < 8)) {
				$('#admin').css('display','block');
			} else {
				$('#admin').fadeIn("fast"); //in
			}
		});
<?php } ?>
	</script>
</body>
</html>
