This module is Config Edit. Using phpconfig it allows
you to edit asterisk configuration files. it includes
acess to:

/etc
/etc/asterisk
/var/www/html/panel
/tftpboot

just untar the files into /var/www/html/admin/modules

there should be one folder in the tarball, the whole
folder goes in /var/www/html/admin/modules.

After placing the folder in the modules directory, you
can install / enable / and use the module in freePBX,
it should appear in the tools section.
